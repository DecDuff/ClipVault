# ClipVault - Customization Summary

## Your Custom Configuration

This ClipVault instance has been customized with your specific settings:

### App Identity
- **App Name**: ClipVault
- **Watermark Text**: ClipVault
- **Primary Brand Color**: #3b82f6 (Blue)

### Subscription Pricing
- **Monthly Plan**: $2.99/month
- **Yearly Plan**: $29.99/year

### Creator Earnings
- **Per 5K Downloads**: $0.99
- **100K Download Bonus**: $50
- **1M Download Bonus**: $500

### Moderation Settings
- **Auto-Hide Threshold**: 10 reports
- **Strikes Before Ban**: 3 strikes

### Features Enabled
- **Creator Mode**: ✓ Enabled
- **Analytics**: ✓ Enabled

### Custom Content Categories

#### Moods (46 options)
sad, heartbreak, breakup, lonely, empty, regret, nostalgia, grief, chill, peaceful, calm, relaxing, dreamy, soft, quiet, slow, hype, intense, aggressive, adrenaline, fast-paced, powerful, confident, dark, moody, cinematic-dark, eerie, mysterious, dramatic, romantic, love, wholesome, intimate, warm, funny, ironic, awkward, chaotic, relatable, deep, philosophical, reflective, motivational, introspective

#### Styles (30 options)
cinematic, movie-style, dramatic lighting, shallow depth of field, aesthetic, visually pleasing, soft tones, clean composition, pov, first-person, handheld, immersive, vintage, retro, film grain, old-school, artistic, abstract, experimental, creative, fast-cut, montage, quick transitions, minimal, simple, clean, neon, warm tones, cool tones, black and white

#### Scenes (42 options)
city, downtown, street, traffic, skyline, night, night drive, dark street, late night, driving, car interior, highway, passenger seat, rain, storm, fog, snow, cloudy, nature, forest, mountains, ocean, beach, sunset, gym, workout, lifting, training, school, classroom, walking, texting, sitting alone, bedroom, window, mirror, hallway, staring, looking out window, scrolling phone

## Files Modified

1. **`src/lib/config.ts`** (NEW)
   - Central configuration file with all custom settings
   - Easy to modify and extend

2. **`.env.customized`** (NEW)
   - Environment variables template with your custom values
   - Rename to `.env` and fill in your API keys

## Next Steps

### 1. Set Up Environment Variables

Rename `.env.customized` to `.env` and fill in your credentials:

```bash
cp .env.customized .env
```

Then edit `.env` with your actual:
- Database connection string
- NextAuth secret (generate with `openssl rand -base64 32`)
- AWS S3 credentials and bucket name
- Stripe API keys and price IDs

### 2. Create Stripe Products

In your Stripe Dashboard, create two subscription products:
- Monthly: $2.99 → Copy the Price ID to `STRIPE_PRICE_ID_MONTHLY`
- Yearly: $29.99 → Copy the Price ID to `STRIPE_PRICE_ID_YEARLY`

### 3. Database Setup

```bash
cd clipvault
npm install
npx drizzle-kit push:pg
```

### 4. Run Development Server

```bash
npm run dev
```

Visit http://localhost:3000

### 5. Configure Stripe Webhooks

Set up webhooks in Stripe Dashboard pointing to:
```
https://your-domain.com/api/webhooks/stripe
```

Events to listen for:
- checkout.session.completed
- customer.subscription.updated
- customer.subscription.deleted

## Customization Files Reference

- **Configuration**: `src/lib/config.ts`
- **Environment**: `.env.customized` (rename to `.env`)
- **Database Schema**: `src/lib/db/schema.ts`
- **API Routes**: `src/server/routers/`

## Support

For detailed setup instructions, see `SETUP_GUIDE.md`
For feature documentation, see `README.md`
