# ClipVault - Configuration Reference

## Overview

This document explains all configuration options for your ClipVault instance.

## Configuration Files

### 1. `src/lib/config.ts`
Central configuration file with app-level settings.

```typescript
export const APP_CONFIG = {
  name: 'ClipVault',
  pricing: { monthly: 2.99, yearly: 29.99 },
  earnings: { per5kDownloads: 0.99, bonus100k: 50, bonus1m: 500 },
  branding: { watermarkText: 'ClipVault', primaryColor: '#3b82f6' },
  moderation: { autoHideThreshold: 10, strikesBeforeBan: 3 },
  features: { enableCreatorMode: true, enableAnalytics: true },
  categories: { moods: [...], styles: [...], scenes: [...] }
}
```

### 2. `.env` (Environment Variables)
Runtime configuration for sensitive data and environment-specific settings.

## Environment Variables

### Required

#### Database
```bash
DATABASE_URL=postgresql://user:password@host:5432/dbname
```
PostgreSQL connection string. Get from your database provider (Railway, Supabase, AWS RDS, etc.)

#### NextAuth
```bash
NEXTAUTH_SECRET=<random-string>
NEXTAUTH_URL=http://localhost:3000
```
- `NEXTAUTH_SECRET`: Generate with `openssl rand -base64 32`
- `NEXTAUTH_URL`: Your app's public URL

#### AWS S3
```bash
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=<your-key>
AWS_SECRET_ACCESS_KEY=<your-secret>
AWS_S3_BUCKET_NAME=clipvault-videos
AWS_S3_PUBLIC_URL=https://your-bucket.s3.amazonaws.com
```
Create S3 bucket and IAM user with S3 permissions.

#### Stripe
```bash
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_ID_MONTHLY=price_...
STRIPE_PRICE_ID_YEARLY=price_...
```
Get from Stripe Dashboard. Create subscription products first.

### Optional (Override Defaults)

#### Branding
```bash
WATERMARK_TEXT=ClipVault
NEXT_PUBLIC_APP_NAME=ClipVault
NEXT_PUBLIC_PRIMARY_COLOR=#3b82f6
```

#### Creator Earnings
```bash
EARNINGS_PER_5K_DOWNLOADS=0.99
BONUS_100K_DOWNLOADS=50
BONUS_1M_DOWNLOADS=500
```

#### Moderation
```bash
AUTO_HIDE_REPORT_THRESHOLD=10
STRIKES_BEFORE_BAN=3
```

#### Features
```bash
ENABLE_CREATOR_MODE=true
ENABLE_ANALYTICS=true
```

## Customizing Categories

### Moods
Edit in `src/lib/config.ts`:
```typescript
categories: {
  moods: [
    'happy', 'sad', 'energetic', // Add your moods
  ]
}
```

### Styles
```typescript
styles: [
  'cinematic', 'aesthetic', 'vintage', // Add your styles
]
```

### Scenes
```typescript
scenes: [
  'city', 'nature', 'gym', // Add your scenes
]
```

## Pricing Configuration

### Display Pricing
In `src/lib/config.ts`:
```typescript
pricing: {
  monthly: 2.99,
  yearly: 29.99,
}
```

### Actual Billing (Stripe)
1. Go to Stripe Dashboard → Products
2. Create "Monthly Subscription" product at $2.99
3. Create "Yearly Subscription" product at $29.99
4. Copy Price IDs to `.env`

**Important**: Stripe Price IDs control actual billing. Config values are for display only.

## Creator Earnings

### Payment Structure
```typescript
earnings: {
  per5kDownloads: 0.99,  // $ per 5,000 downloads
  bonus100k: 50,          // $ bonus at 100,000 downloads
  bonus1m: 500,           // $ bonus at 1,000,000 downloads
}
```

### Calculation Example
- 25,000 downloads = floor(25000/5000) × $0.99 = $4.95
- 100,000 downloads = $19.80 + $50 bonus = $69.80
- 1,000,000 downloads = $198.00 + $50 + $500 = $748.00

### Customizing
Adjust values in `src/lib/config.ts` or override with environment variables.

## Moderation Settings

### Auto-Hide Threshold
```typescript
moderation: {
  autoHideThreshold: 10,  // Hide clip after this many reports
}
```
Clips are hidden (not deleted) until admin review.

### Strike System
```typescript
strikesBeforeBan: 3,  // Ban user after this many strikes
```
Strikes are given for policy violations. Accumulating 3 = automatic ban.

### Ban Types
Defined in database schema:
- `none`: Normal user
- `upload_ban`: Can't upload, can still download
- `soft_ban`: Can't upload or download, can view
- `hard_ban`: Complete account suspension

## Feature Flags

### Creator Mode
```typescript
features: {
  enableCreatorMode: true,
}
```
When `false`, hides creator signup and upload features.

### Analytics
```typescript
enableAnalytics: true,
```
When `false`, hides analytics dashboards and tracking.

## Branding

### Watermark
```typescript
branding: {
  watermarkText: 'ClipVault',
}
```
Text overlay on preview videos. Keep short (under 15 characters).

### Primary Color
```typescript
primaryColor: '#3b82f6',
```
Used for buttons, links, and accents. Any valid CSS color.

## Advanced Configuration

### Video Processing
Edit `src/lib/video.ts` for:
- Watermark position and style
- Thumbnail generation timing
- Video compression settings

### Database Schema
Edit `src/lib/db/schema.ts` for:
- Additional user fields
- Custom clip metadata
- New table structures

### API Routes
Edit `src/server/routers/` for:
- Custom endpoints
- Modified business logic
- Additional integrations

## Configuration Precedence

1. Environment variables (`.env`) - **Highest priority**
2. App config (`src/lib/config.ts`)
3. Default values in code - **Lowest priority**

## Validation

The app validates configuration on startup:
- Missing required env vars → Error
- Invalid pricing → Warning
- Missing Stripe keys in production → Error

## Production Checklist

- [ ] Set `NEXTAUTH_URL` to production domain
- [ ] Use production Stripe keys (`sk_live_`, `pk_live_`)
- [ ] Configure S3 bucket CORS
- [ ] Set up Stripe webhooks
- [ ] Generate strong `NEXTAUTH_SECRET`
- [ ] Enable SSL/HTTPS
- [ ] Set `NODE_ENV=production`

## Troubleshooting

### Video uploads fail
- Check AWS credentials and bucket permissions
- Verify FFmpeg is installed
- Check S3 bucket CORS configuration

### Payments not working
- Verify Stripe keys (test vs live)
- Check webhook endpoint is accessible
- Confirm Price IDs match your products

### Authentication issues
- Regenerate `NEXTAUTH_SECRET`
- Verify `NEXTAUTH_URL` matches your domain
- Clear browser cookies

## Getting Help

1. Check logs: `npm run dev` shows errors
2. Verify environment variables are set
3. Test database connection
4. Confirm external services (Stripe, S3) are configured

---

**Keep this reference handy when customizing your instance!**
