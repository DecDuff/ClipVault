# ClipVault - Quick Start Guide

Your customized ClipVault instance is ready to deploy!

## What's Included

This package contains a fully functional subscription-based video clip marketplace with:

- ✓ Next.js 14 application with TypeScript
- ✓ PostgreSQL database schema
- ✓ Stripe payment integration
- ✓ AWS S3 video storage
- ✓ Complete authentication system
- ✓ Creator dashboard and analytics
- ✓ Moderation and reporting system
- ✓ Your custom configuration pre-applied

## Quick Start (5 minutes)

### 1. Extract the Package
```bash
tar -xzf clipvault-customized-final.tar.gz
cd clipvault
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Set Up Environment
```bash
# Copy the customized template
cp .env.customized .env

# Edit .env and add your credentials:
# - Database URL
# - NextAuth secret (generate: openssl rand -base64 32)
# - AWS credentials
# - Stripe keys
```

### 4. Initialize Database
```bash
npx drizzle-kit push:pg
```

### 5. Run Development Server
```bash
npm run dev
```

Visit http://localhost:3000

## Your Custom Settings

All your settings are pre-configured in:
- `src/lib/config.ts` - App configuration
- `.env.customized` - Environment template

### Pricing
- Monthly: $2.99
- Yearly: $29.99

### Creator Earnings
- $0.99 per 5,000 downloads
- $50 bonus at 100,000 downloads
- $500 bonus at 1,000,000 downloads

### Content Categories
- 46 custom moods
- 30 custom styles
- 42 custom scenes

See `CUSTOMIZATION_SUMMARY.md` for complete details.

## Deployment

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

Add environment variables in Vercel dashboard.

### Docker
```bash
docker build -t clipvault .
docker run -p 3000:3000 clipvault
```

### Other Platforms
Works on any Node.js hosting: AWS, Google Cloud, Azure, Railway, etc.

## Next Steps

1. **Configure Stripe Products**
   - Create monthly ($2.99) and yearly ($29.99) subscription products
   - Add price IDs to `.env`

2. **Set Up S3 Bucket**
   - Create bucket for video storage
   - Configure CORS for uploads
   - Add credentials to `.env`

3. **Configure Webhooks**
   - Stripe webhook: `https://your-domain.com/api/webhooks/stripe`
   - Add webhook secret to `.env`

4. **Customize Branding** (Optional)
   - Update colors in `src/lib/config.ts`
   - Add logo to `public/` directory
   - Modify metadata in `src/app/layout.tsx`

## Documentation

- `README.md` - Full feature documentation
- `SETUP_GUIDE.md` - Detailed setup instructions
- `CUSTOMIZATION_SUMMARY.md` - Your custom configuration details

## Support

For issues or questions:
- Check the documentation files included
- Review the inline code comments
- Consult Next.js, Stripe, and Drizzle ORM documentation

## Architecture

```
clipvault/
├── src/
│   ├── app/           # Next.js pages and API routes
│   ├── components/    # React components
│   ├── lib/           # Utilities (DB, Auth, S3, Video, Config)
│   ├── server/        # tRPC API routers
│   └── types/         # TypeScript definitions
├── public/            # Static assets
└── Configuration files
```

## Tech Stack

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Backend**: tRPC, NextAuth.js
- **Database**: PostgreSQL with Drizzle ORM
- **Payments**: Stripe Checkout & Connect
- **Storage**: AWS S3
- **Video**: FFmpeg processing

---

**Ready to launch your video marketplace!** 🚀
